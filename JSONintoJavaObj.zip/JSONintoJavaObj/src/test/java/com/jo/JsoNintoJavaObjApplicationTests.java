package com.jo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsoNintoJavaObjApplicationTests {

	@Test
	void contextLoads() {
	}

}
