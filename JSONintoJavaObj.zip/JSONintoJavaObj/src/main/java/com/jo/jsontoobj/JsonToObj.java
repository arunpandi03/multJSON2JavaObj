package com.jo.jsontoobj;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jo.model.Bike;
import com.jo.model.Dept;
import com.jo.model.MyDetails;

public class JsonToObj {
	public static void main(String a[]) {
		try {
			byte[] arr=Files.readAllBytes(Paths.get("D:\\arun\\Dept.txt"));
			
			byte[] brr=Files.readAllBytes(Paths.get("D:\\arun\\MyDetails.txt"));
			
			String json = "{ \"id\":7,\"name\":\"R15\",\"amount\":20000,\"status\":\"success\"}";

			
			ObjectMapper objmap = new ObjectMapper();
			
			Dept d = objmap.readValue(arr, Dept.class);
			
			MyDetails myinfo = objmap.readValue(brr, MyDetails.class);
			
			Bike bike = objmap.readValue(json, Bike.class);
			
			System.out.println(d+"\n");
			System.out.println(myinfo+"\n");
			System.out.println(bike);
			
			
			
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	}
		
		
	//	String output = "{\r\n" + " \"id\":1,\r\n" + " \"fname\":\"arun\" ,\r\n" + " \"lname\":\"pandi\",\r\n"
		//		+ " \"age\":22,\r\n" + " \"cmpName\":\"TeleApps\",\r\n" + "}";
		
//		ObjectMapper objmap = new ObjectMapper();
//		{
//			try {
//				MyDetails myinfo = objmap.readValue(output, MyDetails.class);
//
//				try {
//					System.out.println("Id=" + myinfo.getId() + "fname=" + myinfo.getFname() + "lname="
//							+ myinfo.getLname() + "age=" + myinfo.getAge() + "cmpName= " + myinfo.getCmpNamme());
//
//				} catch (Throwable e) {
//					e.printStackTrace();
//				}
//			} catch (JsonProcessingException e) {
//				e.printStackTrace();
//			}
//		}
//	}
//}
