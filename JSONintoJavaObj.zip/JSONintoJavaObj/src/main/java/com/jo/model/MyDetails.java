package com.jo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class MyDetails {
	@JsonProperty("id")
	private long id;
	private String fname;
	private String lname;
	private int age;
	private String cmpName;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCmpName() {
		return cmpName;
	}
	public void setCmpName(String cmpName) {
		this.cmpName = cmpName;
	}
	@Override
	public String toString() {
		return "MyDetails [id=" + id + ", fname=" + fname + ", lname=" + lname + ", age=" + age + ", cmpName=" + cmpName
				+ "]";
	}
	
}
