package com.jo.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class Dept {
	@JsonProperty("dCode")
	private int dCode;
	private String dName;
	private List<String> sub;
	
	public int getdCode() {
		return dCode;
	}
	public void setdCode(int dCode) {
		this.dCode = dCode;
	}
	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}
	public List<String> getSub() {
		return sub;
	}
	public void setSub(List<String> sub) {
		this.sub = sub;
	}
	@Override
	public String toString() {
		return "Dept  = [dCode=" + dCode + ", dName=" + dName + ",sub=" + sub + "]";
	}
	

}
